package cr.tuasada.asadaapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ASADAApp() }
    }
}

@Composable
fun ASADAApp() {
    var currentScreen by remember { mutableStateOf("home") }

    when (currentScreen) {
        "home" -> HomeScreen(
            onInventarioClick = { currentScreen = "inventario" },
            onFacturacionClick = { currentScreen = "facturacion" }
        )
        "inventario" -> InventarioScreen(onBack = { currentScreen = "home" })
        "facturacion" -> FacturacionScreen(onBack = { currentScreen = "home" })
    }
}

@Composable
fun HomeScreen(onInventarioClick: () -> Unit, onFacturacionClick: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Bienvenido a la ASADA", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onInventarioClick, modifier = Modifier.fillMaxWidth()) { Text("Inventario") }
        Spacer(Modifier.height(10.dp))
        Button(onClick = onFacturacionClick, modifier = Modifier.fillMaxWidth()) { Text("Facturación") }
    }
}
